
#include <iostream>
#include <vector>
#include <tuple>
#include <utility>
using namespace std;

double fo(double db) {
    return db * 2;
}
/*
int go(int a) {
    return a * 10;
}
*/
int go(int a, double b) {
    return a*b*10;
}
struct test {
    char arr[10] = {'\0'};
};
std::pair<int, std::string> ho(const std::string& s, int i, const test& t) {
    char buf[256];
    snprintf(buf, sizeof(buf), "%s-%d-%s", s.c_str(), i, t.arr);
    return {i, buf};
}

template<class Func, class... Args>
auto
//Do(Func& func, Args&&... args) -> decltype(func(args...)) {
Do(Func& func, Args&&... args) {
    return func(args...);
}
template<class... Args>
struct input_t {
    using params_list_t = std::tuple<Args...>;
    params_list_t params;
    input_t(Args&&... args) : params(std::forward<Args>(args)...)
    {}
};

template<class Func, class Params, std::size_t... Is>
auto
run(Func& func, const Params& paras, std::index_sequence<Is...>) {
    return func(std::get<Is>(paras)...);
}
template<class Func, class... Args>
auto
Do2(Func& func, const std::vector<input_t<Args...>>& inputs) {
    typename input_t<Args...>::params_list_t params_type;
    using result_t =
        decltype(
            run(func, params_type, std::index_sequence_for<Args...>{})
        );

    vector<result_t> results;
    for (const auto& input : inputs) {
        results.emplace_back(
            run(func, input.params, std::index_sequence_for<Args...>{})
        );
    }
    return results;
}

int main()
{
    Do(fo, 12.3);
    cout << Do(fo, 11.1) << endl;
    cout << Do(go, 10, 8.41) << endl;
    input_t<int> input1(23);
    input_t<int, double> input2(14, 32.1);
    vector<input_t<double>> vec = {43.2, 12.3};
    Do2(fo, vec);
    
    vector<input_t<double>> vec1 = {11.2, 34.11, 56.66};
    Do2(fo, vec1);
    
    vector<input_t<int, double>> vec2 = {input2, {18, 2.1}};
    Do2(go, vec2);
    
    input_t<std::string, int, test> input_custom("abcd", 100, test{"again"});
    vector<input_t<std::string, int, test>> vv = {input_custom};
    auto ret = Do2(ho, vv);
    for (const auto& r : ret) {
        cout << r.first << "," << r.second << endl;
    }
    
    vector<input_t<std::string, int, test>> vv1 = {input_custom, input_custom};
    auto ret1 = Do2(ho, vv1);
    for (const auto& r : ret1) {
        cout << r.first << "," << r.second << endl;
    }

    return 0;
}
