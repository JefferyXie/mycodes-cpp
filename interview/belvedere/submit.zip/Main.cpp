#include <iostream>
#include <vector>
#include <tuple>
#include <utility>
#include <functional>
#include <type_traits>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>
#include <chrono>
#include <ctime>
#include <random>
#include <cstring>
#include "Math.h"

/* Our trading system contains a number of calculation engines that perform calcs on a request basis.
 * The goal of this assignment is to come up with a generic framework for accelerating the calculations
 * in these engines. We have given you a benchmark test that provides a workload that is representative
 * of the types of calculations we are trying to accelerate.
 *
 * The goal of this assignment is to get the provided test to run as quickly as possible.
 *
 * Your solution should be generic. It should be easily extendible to methods other than IsPrime. It should
 * also be extendible to calculations with various function signatures. You should not modify IsPrime or Math.h.
*/

/*
 * Original codes from assignment
 * 
static std::vector<int64_t> DoCalc(const std::vector<int64_t>& inputs)
{
  std::vector<int64_t> outputs;
  outputs.reserve(inputs.size());
  for(auto input : inputs)
  {
    outputs.push_back(MathLibrary::Math::IsPrime(input));
  }

  return outputs;
}
int main(int argc, char * argv[])
{
  std::default_random_engine generator;
  std::uniform_int_distribution<int64_t> distribution(1, 1000000000000);
  std::vector<int64_t> inputs;
  for(int32_t i = 0; i < 500000; ++i)
  {
    inputs.push_back(distribution(generator));
  }
  auto tick = std::chrono::high_resolution_clock::now();
  std::vector<int64_t> outputs = DoCalc(inputs);
  auto tock = std::chrono::high_resolution_clock::now();
  std::cout << "finished: " << (std::chrono::duration_cast<std::chrono::duration<double>>(tock - tick)).count() << std::endl;
  return 0;
};
*/

namespace calc_lib {

struct extra_data {
    char arr[10] = {'\0'};
};

std::pair<int, std::string>
my_calc(const std::string& s, int i, const extra_data& t) {
    char buf[256];
    snprintf(buf, sizeof(buf), "%s-%d-%s", s.c_str(), i, t.arr);
    return {i, buf};
}

}

// 
// generic event used in thread pool
struct event_t {
    unsigned index = 0;
    event_t(unsigned idx) : index(idx) {}
    virtual void run() = 0;
};
template<class CalcF, class CallbackF, class... Args>
struct event_impl_t : public event_t {
    std::tuple<Args...> paras;
    CalcF f_calc;
    CallbackF f_cb;
    
    event_impl_t(unsigned idx,
        CalcF& calc, CallbackF& cb,
        const std::tuple<Args...>& args)
        : event_t(idx),
          paras(args),
          f_calc(std::forward<CalcF>(calc)),
          f_cb(std::forward<CallbackF>(cb))
    {}

    template<std::size_t... Is>
    auto run_calc(std::index_sequence<Is...>) {
        return f_calc(std::get<Is>(paras)...);
    }

    void run() override {
        auto result = run_calc(std::index_sequence_for<Args...>{});
        f_cb(index, std::move(result));
    }
};
// special event used as final event when calculation is done
struct event_all_done_t : public event_t {
    std::function<void()> f_notify_all_done;
    event_all_done_t(std::function<void()>&& cb)
        : event_t(0),
          f_notify_all_done(std::move(cb))
    { }
    void run() override {
        f_notify_all_done();
    }
};

//
// generic thread pool
struct thread_pool {
    // TODO: below 3 can be merged into 1 status variable
    bool stopped = false;
    bool waiting_all_done = false;
    bool events_all_done_added = false;
    
    std::mutex mu;
    std::condition_variable cv;
    
    std::queue<event_t*> events;
    std::vector<std::thread> threads;
    
    thread_pool() {
    }
    ~thread_pool() {
        stop();
    }
    // to start running thread pool
    size_t start() {
        stopped = false;
        auto concurrent_num = std::thread::hardware_concurrency()+2;
        for (unsigned i = 0; i < concurrent_num; ++i) {
            threads.emplace_back(do_work, this, i);
        }
        return concurrent_num;
    }

    // to stop running thread pool
    void stop() {
        std::unique_lock<std::mutex> locker(mu);
        stopped = true;
        while (!events.empty()) {
            std::cout << "[WARNING]: unfinished event!" << std::endl;
            events.pop();
        }
        locker.unlock();
        for (auto& th : threads) {
            th.join();
        }
        threads.clear();
    }

    // add event to the queue, event is allocated by caller
    size_t push(event_t* event) {
        std::unique_lock<std::mutex> locker(mu);
        waiting_all_done = false;
        events.push(event);
        return events.size();
    }

    // wait until all events are handled
    void wait_until_all_done() {
        std::unique_lock<std::mutex> locker(mu);
        waiting_all_done = true;
        while (!events.empty()) {
            cv.wait(locker, [this]() {
                std::cout << "received notification:"
                          << events.size() << std::endl;
                return events.empty();
            });
            break;
        }
    }

    // thread proc function
    static void do_work(thread_pool* pool, unsigned th_idx) {
        event_t* event = nullptr;
        while (1) {
            {
                std::unique_lock<std::mutex> locker(pool->mu);
                if (pool->events.empty()) {
                    if (pool->waiting_all_done && !pool->events_all_done_added)
                    {
                        pool->events.push(new event_all_done_t{
                            [pool]() {
                                std::unique_lock<std::mutex> lk(pool->mu);
                                pool->waiting_all_done = false;
                                pool->events_all_done_added = false;
                                pool->cv.notify_one();
                            }
                        });
                        std::cout << "thread " << th_idx
                                  << ",new event_all_done_t" << std::endl;
                        pool->events_all_done_added = true;
                    }
                    if (pool->stopped) break;
                    else continue;
                }
                event = pool->events.front();
                pool->events.pop();
            }
            event->run();
        }
    }
};

// generic callback when a calc is finished
template<class T>
void callback(std::vector<T>& results, unsigned idx, T result) {
    if (results.size() <= idx) results.resize(idx+1);
    results[idx] = result;
}

// helper function that makes event_impl_t instance
template<class CalcF, class CallbackF, class... Args>
event_impl_t<CalcF, CallbackF, Args...>
make_event(unsigned idx, CalcF&& calc, CallbackF&& cb, const std::tuple<Args...>& args)
{
    return event_impl_t<CalcF, CallbackF, Args...>(
        idx,
        std::forward<CalcF>(calc),
        std::forward<CallbackF>(cb),
        args);
}

// generic input data
template<class... Args>
struct input_t {
    using params_list_t = std::tuple<Args...>;
    params_list_t params;
    input_t(Args&&... args) : params(std::forward<Args>(args)...)
    {}
};

template<class Func, class Params, std::size_t... Is>
auto Run(Func& func, const Params& paras, std::index_sequence<Is...>) {
    return func(std::get<Is>(paras)...);
}

// generic DoCalc interface
template<class Func, class... Args>
auto DoCalc(Func& func, const std::vector<input_t<Args...>>& inputs) {
    typename input_t<Args...>::params_list_t params_type;
    using result_t =
        decltype(
            Run(func, params_type, std::index_sequence_for<Args...>{})
        );
    std::vector<result_t> results;
    results.resize(inputs.size());

    thread_pool pool;
    auto num_threads = pool.start();
    std::cout << num_threads << " have started!" << std::endl;
    
    using namespace std::placeholders;
    
    auto func_cb = std::bind(callback<result_t>, std::ref(results), _1, _2);
    using event_type = decltype(make_event(0, func, func_cb, inputs.begin()->params));
    std::vector<event_type> events;
    events.reserve(inputs.size());
    for (unsigned i = 0; i < inputs.size(); ++i) {
        events.push_back(
                make_event(i, func, func_cb, inputs[i].params)
            );
        pool.push(&events.back());
    }
    std::cout << "will wait_until_all_done - " << std::endl;
    pool.wait_until_all_done();
    std::cout << "All DONE!" << std::endl;
    return results;
}

int main(int argc, char * argv[])
{
// case 1: MathLibrary::Math::IsPrime
{
    std::default_random_engine generator;
    std::uniform_int_distribution<int64_t> distribution(1, 1000);
    std::vector<input_t<int64_t>> inputs;
    for(int32_t i = 0; i < 500; ++i)
    {
        inputs.push_back(distribution(generator));
    }
    auto tick = std::chrono::high_resolution_clock::now();
    auto outputs = DoCalc(MathLibrary::Math::IsPrime, inputs);
    auto tock = std::chrono::high_resolution_clock::now();

    for (unsigned i = 0; i < inputs.size(); ++i) {
        std::cout << std::get<0>(inputs[i].params) << "->" 
                  << outputs[i] 
                  << std::endl;
    }

    std::cout << "finished: "
              << (std::chrono::duration_cast<std::chrono::duration<double>>
                    (tock - tick)).count()
              << std::endl;
}

// case 2: calc_lib::my_calc
{
    using result_t = std::pair<int, std::string>;
    std::vector<result_t> results;
    
    std::vector<input_t<std::string, int, calc_lib::extra_data>> inputs;
    for (unsigned i = 0; i < 100; ++i) {
        inputs.emplace_back("abc", i, calc_lib::extra_data{"xyz"});
    }
    
    auto tick = std::chrono::high_resolution_clock::now();
    auto outputs = DoCalc(calc_lib::my_calc, inputs);
    auto tock = std::chrono::high_resolution_clock::now();
    
    for (unsigned i = 0; i < inputs.size(); ++i) {
        std::cout << "(" 
                  << std::get<0>(inputs[i].params) << ","
                  << std::get<1>(inputs[i].params) << ","
                  << std::get<2>(inputs[i].params).arr << ")->("
                  << outputs[i].first << ","
                  << outputs[i].second << ")"
                  << std::endl;
    }

    std::cout << "finished: "
              << (std::chrono::duration_cast<std::chrono::duration<double>>
                    (tock - tick)).count()
              << std::endl;
}

    return 0;
};
