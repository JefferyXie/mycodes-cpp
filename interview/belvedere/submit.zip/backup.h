//
// generialize the input data
template<class T>
struct input_base_t {
    static std::string type;
    std::string get_type() { return type; }
};

struct input_IsPrime_t : public input_base_t<input_IsPrime_t> {
    int64_t number = 0;
};
template<>
std::string input_base_t<input_IsPrime_t>::type = "IsPrime";

struct input_OtherCalc_t : public input_base_t<input_OtherCalc_t> {
    char    member_1 = '\0';
    int32_t member_2 = 0;
    double  member_3 = 0;
    std::string member_4;
};
template<>
std::string input_base_t<input_OtherCalc_t>::type = "OtherCalc";

// 
// generalize the output result
template<class T>
struct output_base_t {
    const T& input;
    std::string get_type() { return input.get_type(); }
    output_base_t(const T& input_) : input(input_)
    {}
};

struct output_IsPrime_t : public output_base_t<input_IsPrime_t> {
    bool is_prime = false;
    output_IsPrime_t(input_IsPrime_t input_, bool prime_)
    : output_base_t(input_), is_prime(prime_)
    {}
};

struct output_OtherCalc_t : public output_base_t<input_OtherCalc_t> {
    int32_t member_1 = 0;
    std::string member_2;
};


template<class... Args>
struct input_t {
    std::tuple<Args...> params;
};
template<class T>
struct output_t {
    T result;
};


